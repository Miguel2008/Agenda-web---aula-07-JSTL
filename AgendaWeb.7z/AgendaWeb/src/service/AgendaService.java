package service;

import java.util.ArrayList;

import dao.AgendaDAO;
import model.Agenda;

public class AgendaService {
	
	AgendaDAO dao;

	public AgendaService() {
		dao = new AgendaDAO();
	}

	public void inserir(Agenda agenda) {
		dao.inserir(agenda);
	}

	public void atualizar(Agenda agenda) {
		dao.atualizar(agenda);
	}

	public void excluir(Agenda agenda) {
		dao.excluir(agenda);
	}

	public void pesquisar(Agenda agenda) {
		dao.pesquisar(agenda);
		//return agenda;
	}
	
	public ArrayList<Agenda> findAll(){
		return dao.findAll();
	}
}
