package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import model.Agenda;

public class AgendaDAO {
		
		// METODO INSERIR
		public void inserir(Agenda agenda) {
			String sqlInsert = "INSERT INTO pessoa(nome, endereco, telefone, email) VALUES (?, ?, ?, ?)";
			// usando o try with resources do Java 7, que fecha o que abriu
			try (Connection conn = ConnectionFactory.obtemConexao(); PreparedStatement stm = conn.prepareStatement(sqlInsert);) {
				stm.setString(1, agenda.getNome());
		         stm.setString(2, agenda.getEndereco());
		         stm.setString(3, agenda.getTelefone());
		         stm.setString(4, agenda.getEmail());
				stm.execute();
				
				public ArrayList<Agenda> findAll() {
					ArrayList<Agenda> paises = new ArrayList<Agenda>();
					Agenda agenda;
					
				String sqlQuery = "SELECT LAST_INSERT_ID()";
				try (PreparedStatement stm2 = conn.prepareStatement(sqlQuery); ResultSet rs = stm2.executeQuery();) {
					if (rs.next()) {
						agenda.setIdPessoa(rs.getInt(1));
					}
				} catch (SQLException e) {
					e.printStackTrace();
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}

		// METODO ATUALIZAR
		public void atualizar(Agenda agenda) {
			String sqlUpdate = "UPDATE pessoa SET nome=?, endereco=?, telefone=?, email=? WHERE id = ?";
			// usando o try with resources do Java 7, que fecha o que abriu
			try (Connection conn = ConnectionFactory.obtemConexao(); PreparedStatement stm = conn.prepareStatement(sqlUpdate);) {
				stm.setString(1, agenda.getNome());
				stm.setString(2, agenda.getEndereco());
	         stm.setString(3, agenda.getTelefone());
	         stm.setString(4, agenda.getEmail());
				stm.setInt(5, agenda.getIdPessoa());
				stm.execute();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}

		// METODO EXCLUIR
		public void excluir(Agenda agenda) {
			String sqlDelete = "DELETE FROM pessoa WHERE id = ?";
			// usando o try with resources do Java 7, que fecha o que abriu
			try (Connection conn = ConnectionFactory.obtemConexao(); PreparedStatement stm = conn.prepareStatement(sqlDelete);) {
				stm.setInt(1, agenda.getIdPessoa());
				stm.execute();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		
		// METODOD PESQUISAR
		public Agenda pesquisar(Agenda agenda) {
			//Agenda agenda = new Agenda();
			String sqlSelect = "SELECT * FROM pessoa WHERE id = ?";
			// usando o try with resources do Java 7, que fecha o que abriu
			try (Connection conn = ConnectionFactory.obtemConexao(); PreparedStatement stm = conn.prepareStatement(sqlSelect);) {
				stm.setInt(1, agenda.getIdPessoa());
				try (ResultSet rs = stm.executeQuery();) {
					/*if (rs.next()) {						
						agenda.setIdPessoa(rs.getInt("id"));
						agenda.setNome(rs.getString("nome"));
						agenda.setEndereco(rs.getString("endereco"));
						agenda.setTelefone(rs.getString("telefone"));
						agenda.setEmail(rs.getString("email"));
					} else {
						agenda.setIdPessoa(-1);
						agenda.setNome(null);
						agenda.setEndereco(null);
						agenda.setTelefone(null);
						agenda.setEmail(null);
					}*/
					
					while (rs.next()) {
						agenda.setIdPessoa(rs.getInt("id"));
						agenda.setNome(rs.getString("nome"));
						agenda.setEndereco(rs.getString("endereco"));
						agenda.setTelefone(rs.getString("telefone"));
						agenda.setEmail(rs.getString("email"));				
			        }
					
				} catch (SQLException e) {
					e.printStackTrace();
				}
			} catch (SQLException e1) {
				System.out.print(e1.getStackTrace());
			}
			return agenda;

		}

		
	
}
