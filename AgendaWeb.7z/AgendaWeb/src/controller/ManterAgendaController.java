package controller;

import java.io.IOException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import model.Agenda;
import service.AgendaService;

/**
 * Servlet implementation class ManterAgendaController
 */
@WebServlet("/ManterAgenda.do")
public class ManterAgendaController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//String idPessoa = request.getParameter("idPessoa");
		String nome = request.getParameter("nome");
		String endereco = request.getParameter("endereco");
		String telefone = request.getParameter("fone");
		String email = request.getParameter("email");
		
		
		//instanciar o javabean
		Agenda agenda = new Agenda();
		//agenda.setIdPessoa(idPessoa);
		agenda.setNome(nome);
		agenda.setEndereco(endereco);
		agenda.setTelefone(telefone);
		agenda.setEmail(email);
		
		
		//instanciar o service
		AgendaService ps = new AgendaService();
		ps.inserir(agenda);
		//agenda = ps.carregar(agenda.getIdPessoa());
		
		
		//enviar para o jsp
		request.setAttribute("agenda", agenda);
		request.setAttribute("newag", ps.findAll());
		RequestDispatcher view = request.getRequestDispatcher("AgendaNew.jsp");
		view.forward(request, response);
		
	}

}
